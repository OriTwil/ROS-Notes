---------------------------------
Do not make GitHub pull requests!
---------------------------------

Ceres development happens on
[Gerrit](https://ceres-solver.googlesource.com/), including both
repository hosting and code reviews.

This GitHub Repository is a continuously updated mirror which is
primarily meant for issue tracking.

Please see our
[Contributing to Ceres Guide](http://ceres-solver.org/contributing.html)
for more details.
